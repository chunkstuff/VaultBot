# core/bot/cogs/makemeworseplus/playlist_api.py
import secrets, random, json
from urllib.parse import urlencode
from config.settings import settings
from utils.logger_factory import setup_logger
from .playlist_utils import extract_collection_category, is_priority_collection, normalize_name, is_mmw_name

logger = setup_logger(__name__)

async def fetch_items_by_jellyfin_collection(jellyfin_client, name: str) -> list:
    logger.info(f"[fetch_items_by_jellyfin_collection] {name}")
    coll_query = urlencode({"IncludeItemTypes": "Collection", "Recursive": "true"})
    coll_response = await jellyfin_client.api.get(f"/Items?{coll_query}")
    match = next((c for c in coll_response.get("Items", []) if c["Name"].strip().lower() == name.strip().lower()), None)
    if not match:
        logger.warning(f"[fetch_items_by_jellyfin_collection] No match for {name}")
        return []
    child_query = urlencode({
        "ParentId": match["Id"],
        "IncludeItemTypes": "Audio",
        "Recursive": "true",
        "Fields": "Tags,Genres,BasicSyncInfo,Path"
    })
    child_response = await jellyfin_client.api.get(f"/Items?{child_query}")
    return child_response.get("Items", [])

async def fetch_items_by_path_category(jellyfin_client, name: str) -> list:
    logger.info(f"[fetch_items_by_path_category] {name}")
    query = urlencode({
        "IncludeItemTypes": "Audio",
        "Recursive": "true",
        "Fields": "Tags,Genres,BasicSyncInfo,Path"
    })
    response = await jellyfin_client.api.get(f"/Items?{query}")
    all_items = response.get("Items", [])

    if name.startswith("Unethical Collection: "):
        target_cat = name.split(": ", 1)[1].strip().lower()
        return [
            item for item in all_items
            if (col := extract_collection_category(item.get("Path", "")))[0].strip().lower() == "sir's unethical collection"
            and col[1].strip().lower() == target_cat
        ]
    else:
        target_cat = name.strip().lower()
        return [
            item for item in all_items
            if extract_collection_category(item.get("Path", ""))[1].strip().lower() == target_cat
        ]

def filter_by_tags(items: list, tags: list[str]) -> list:
    if not tags:
        return items
    tl = [t.lower() for t in tags]
    out = []
    for it in items:
        if any(t in [x.lower() for x in it.get("Tags", [])] for t in tl):
            out.append(it)
    return out

def _choose_guaranteed_items(pools: dict, used_ids: set) -> list:
    guaranteed = []
    for name, pool in pools.items():
        if not pool:
            continue
        choice = random.choice(pool)
        guaranteed.append(choice)
        used_ids.add(choice["Id"])
        coll, cat = extract_collection_category(choice.get("Path", ""))
        logger.info(f"[guaranteed] '{choice['Name']}' ({coll}/{cat}) from '{name}'")
    return guaranteed

def _choose_items_round_robin(pools: dict, used_ids: set, needed: int) -> list:
    extra = []
    iters = {name: (item for item in pool if item["Id"] not in used_ids) for name, pool in pools.items()}
    while needed > 0 and any(iters.values()):
        for name, iterator in iters.items():
            if needed <= 0: break
            try:
                item = next(iterator)
            except StopIteration:
                continue
            extra.append(item); used_ids.add(item["Id"]); needed -= 1
            coll, cat = extract_collection_category(item.get("Path", ""))
            logger.info(f"[round_robin] '{item['Name']}' ({coll}/{cat}) from '{name}'")
    return extra

async def _get_filler_items(jellyfin_client, count: int, used_ids: set, tags: list[str]) -> list:
    query = urlencode({"IncludeItemTypes": "Audio", "Recursive": "true", "SortBy": "Random", "Fields": "Tags,BasicSyncInfo,Path"})
    response = await jellyfin_client.api.get(f"/Items?{query}")
    all_items = [it for it in response.get("Items", []) if it.get("Id") not in used_ids]
    tagged = filter_by_tags(all_items, tags)
    curve = [it for it in all_items if it not in tagged]
    sample_curve = random.sample(curve, min(2, count)) if curve else []
    sample_tagged = random.sample(tagged, min(count - len(sample_curve), len(tagged))) if tagged else []
    filler = sample_tagged + sample_curve
    random.shuffle(filler)
    for it in filler:
        coll, cat = extract_collection_category(it.get("Path", ""))
        logger.info(f"[filler] '{it['Name']}' ({coll}/{cat})")
    return filler[:count]

async def generate_random_playlist(jellyfin_client, count: int, tags: list[str] | None = None) -> list:
    used_ids = set()
    query = urlencode({"IncludeItemTypes": "Audio", "Recursive": "true", "SortBy": "Random", "Fields": "Tags,BasicSyncInfo,Path"})
    response = await jellyfin_client.api.get(f"/Items?{query}")
    all_items = [it for it in response.get("Items", []) if it.get("Id") not in used_ids]
    tag_pools = {tag: [it for it in all_items if tag.lower() in [t.lower() for t in it.get("Tags", [])]] for tag in (tags or [])}
    guaranteed = _choose_guaranteed_items(tag_pools, used_ids)
    extra_tagged = _choose_items_round_robin(tag_pools, used_ids, int(count * 0.75) - len(guaranteed))
    filler = await _get_filler_items(jellyfin_client, count - len(guaranteed) - len(extra_tagged), used_ids, [])
    final = guaranteed + extra_tagged + filler
    random.shuffle(final)
    logger.info(f"[generate_random_playlist] Assembled {len(final)} items")
    return final

async def generate_playlist(jellyfin_client, count: int, collections: list[str], tags: list[str] | None = None) -> list:
    if not collections:
        logger.warning("[generate_playlist] No collections provided — falling back to tags.")
        return await generate_random_playlist(jellyfin_client, count, tags)

    items_by_collection, used_ids = {}, set()
    for name in collections:
        items = await (fetch_items_by_jellyfin_collection(jellyfin_client, name) if is_priority_collection(name)
                       else fetch_items_by_path_category(jellyfin_client, name))
        if not items:
            logger.warning(f"[generate_playlist] No items for '{name}'")
            continue
        filtered = filter_by_tags(items, tags)
        items_by_collection[name] = filtered or items
        logger.info(f"[generate_playlist] {len(filtered)}/{len(items)} matched tags in '{name}'")

    guaranteed = _choose_guaranteed_items(items_by_collection, used_ids)
    extra = _choose_items_round_robin(items_by_collection, used_ids, int(count * random.uniform(0.65, 0.75)) - len(guaranteed))
    remainder = count - len(guaranteed) - len(extra)
    filler = await _get_filler_items(jellyfin_client, max(0, remainder), used_ids, tags or [])
    final = _reorder_long_items_last(guaranteed + extra + filler)
    random.shuffle(final)
    logger.info(f"[generate_playlist] Final size {len(final)}")
    return final

def _reorder_long_items_last(items: list) -> list:
    def mins(item):
        ticks = item.get("RunTimeTicks") or item.get("BasicSyncInfo", {}).get("RunTimeTicks", 0)
        return ticks / 10_000_000 / 60
    short = [i for i in items if mins(i) <= 120]
    long = [i for i in items if mins(i) > 120]
    logger.info(f"[reorder] {len(short)} short, {len(long)} long")
    return short + long

async def create_playlist(
    jellyfin_client,
    user_id: str,
    items: list,
    name: str | None = None,
    name_prefix: str = "Make Me Worse+",
) -> tuple[str, str]:
    """
    Create a Jellyfin playlist and return (playlist_id, playlist_name).

    Normally, pass an explicit `name` (e.g., "<jf_username>'s Get Worse Playlist #n").
    If `name` is None, a fallback name is generated using `name_prefix` + random hex.
    """
    playlist_name = name or f"{name_prefix} ({secrets.token_hex(4)})"
    logger.info(f"[create_playlist] {playlist_name} with {len(items)} items")

    payload = {
        "Name": playlist_name,
        "Ids": [it["Id"] for it in items if "Id" in it],
        "UserId": user_id,
        "IsPublic": False
    }
    playlist = await jellyfin_client.api.post("/Playlists", data=payload)
    if not playlist or not playlist.get("Id"):
        raise RuntimeError("No playlist ID returned")

    logger.info(f"[create_playlist] ID: {playlist['Id']}")
    return playlist["Id"], playlist_name


def build_playlist_url(playlist_id: str) -> str:
    return f"{settings.JELLYFIN_URL}/web/#/details?id={playlist_id}&serverid={settings.JELLYFIN_SERVER_ID}"

async def fetch_user_mmw_playlist_names(jellyfin_client, jf_user_id: str) -> set[str]:
    q = urlencode({"IncludeItemTypes": "Playlist", "Recursive": "true", "UserId": jf_user_id, "Fields": "BasicSyncInfo"})
    resp = await jellyfin_client.api.get(f"/Items?{q}")
    items = resp.get("Items", []) if isinstance(resp, dict) else []
    names = set()
    for pl in items:
        name = pl.get("Name") or pl.get("NameSort") or ""
        if is_mmw_name(name):
            names.add(name)
    logger.info(f"[fetch_user_mmw_playlist_names] {len(names)} for {jf_user_id}")
    return names
