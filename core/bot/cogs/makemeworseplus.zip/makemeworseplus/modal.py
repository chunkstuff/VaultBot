import discord
from discord.ui import Modal, TextInput
import random
from utils.logger_factory import setup_logger
from utils.validation import match_multiple

logger = setup_logger(__name__)

class WorseModal(Modal, title="🎧 Make Me Worse+"):
    def __init__(self, callback, collection_list):
        super().__init__()
        self.callback_fn = callback
        self.collection_list = collection_list

        # Get 3 random samples from the collection list, or fall back if not enough
        samples = random.sample(collection_list, k=3) if len(collection_list) >= 3 else ["Advanced", "Store", "Phallus"]

        self.num_files = TextInput(
            label="How many audio files?",
            placeholder="Leave blank for random; min files: 5; max files: 30)",
            required=False,
            max_length=3,
        )
        self.collection1 = TextInput(label="Collection 1", placeholder=f"e.g. {samples[0]}", required=False)
        self.collection2 = TextInput(label="Collection 2", placeholder=f"e.g. {samples[1]}", required=False)
        self.collection3 = TextInput(label="Collection 3", placeholder=f"e.g. {samples[2]}", required=False)
        self.tags = TextInput(
            label="Preferred Tags (comma-separated, max 3)",
            placeholder="e.g. Findom, Sir Dominic Scott, ABDL",
            required=False,
            max_length=100
        )

        self.add_item(self.num_files)
        self.add_item(self.collection1)
        self.add_item(self.collection2)
        self.add_item(self.collection3)
        self.add_item(self.tags)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            try:
                if self.num_files.value:
                    count = int(self.num_files.value)
                    if count < 5 or count > 30:
                        raise ValueError("Number must be between 5 and 30")
                else:
                    count = random.randint(5, 15)
            except ValueError:
                await interaction.response.send_message("⚠️ Please enter a number between 5 and 30.", ephemeral=True)
                return

            collection_inputs = [self.collection1.value, self.collection2.value, self.collection3.value]
            resolved_collections = match_multiple(collection_inputs, self.collection_list)

            resolved_tags = []
            if self.tags.value:
                resolved_tags = [tag.strip() for tag in self.tags.value.split(",") if tag.strip()]

            await self.callback_fn(interaction, count, resolved_collections, resolved_tags)

        except Exception as e:
            logger.error(f"WorseModal submission failed: {e}")
            await interaction.response.send_message("❌ Something went wrong while processing your input.", ephemeral=True)

