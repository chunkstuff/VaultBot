# core/bot/cogs/makemeworseplus/playlist_utils.py
from pathlib import Path

def extract_collection_category(path: str) -> tuple[str, str]:
    parts = Path(path).parts
    try:
        media_index = parts.index("media")
        collection = parts[media_index + 1] if len(parts) > media_index + 1 else "Unknown"
        category = parts[media_index + 2] if len(parts) > media_index + 2 else "Unknown"
        return collection, category
    except ValueError:
        return "Unknown", "Unknown"

def normalize_name(s: str) -> str:
    return (s or "").lower().replace(" ", "")

# 🔑 one canonical marker for all DB queries / detection
NAME_MARKER = "getworseplaylist#"

PRIORITY_COLLECTIONS = {
    "Sir's Core Hypnos",
    "Sir Dominic Store",
    "Subsys Files",
    "Locktober 2024",
    "Locktober 2025",
}

def is_priority_collection(name: str) -> bool:
    return name in PRIORITY_COLLECTIONS

def is_mmw_name(name: str) -> bool:
    return NAME_MARKER in normalize_name(name)
