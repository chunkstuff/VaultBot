import discord
from discord.ui import View, Button
from config.settings import settings
from .modal import WorseModal
from .playlist_api import (
    generate_playlist,
    create_playlist,
    build_playlist_url,
)
from .playlist_db import (
    log_playlist_creation,
    expire_old_playlists,
    count_active_playlists,
    reconcile_deleted_playlists,
    get_next_playlist_number,
    build_sequential_name,
    log_playlist_items,
)
from utils.logger_factory import setup_logger
import traceback

logger = setup_logger(__name__)


class WorseView(View):
    def __init__(self, bot, collection_list):
        super().__init__(timeout=None)
        self.bot = bot
        self.collection_list = collection_list

    @discord.ui.button(label="Get Worse", style=discord.ButtonStyle.danger, custom_id="make_me_worse_button")
    async def worse_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(WorseModal(
            callback=self._handle_submission,
            collection_list=self.collection_list
        ))

    @discord.ui.button(label="Available Collections", style=discord.ButtonStyle.secondary, custom_id="available_collections_button")
    async def show_collections_button(self, interaction: discord.Interaction, button: Button):
        try:
            valid_collections = [c for c in self.collection_list if c.lower() != "unknown"]
            valid_collections.sort()

            midpoint = len(valid_collections) // 2
            left_column = valid_collections[:midpoint]
            right_column = valid_collections[midpoint:]

            embed = discord.Embed(
                title="📚 Available Collections",
                description=(
                    "Use **unique or distinctive words** from these names (e.g. `Advanced`, `Store`, `Phallus`) "
                    "to guide your playlist when filling out the Make Me Worse Generator. "
                    "Full names aren't necessary, but results may vary depending on overlap (e.g. `Lull`, `Lullaby`)."
                ),
                color=discord.Color.purple()
            )
            embed.add_field(name="Collections (A–S)", value="\n".join(left_column) or "—", inline=True)
            embed.add_field(name="Collections (S–Z)", value="\n".join(right_column) or "—", inline=True)

            await interaction.response.send_message(embed=embed, ephemeral=True)

        except Exception as e:
            logger.error(f"[show_collections_button] Failed to show collections: {e}")
            await interaction.response.send_message("❌ Failed to load collection list.", ephemeral=True)

    async def _handle_submission(
        self,
        interaction: discord.Interaction,
        num_files: int,
        collections: list[str],
        tags: list[str],
    ):
        user = interaction.user
        jf_id = self._get_jellyfin_user_id(user)
        logger.info(f"[_handle_submission] Jellyfin ID for {user}: {jf_id}")

        if not jf_id:
            await self._respond_not_linked(interaction)
            return

        playlist_url = None  # keep this defined for the Forbidden branch

        try:
            # Access VaultPulseDB from bot dependency chain
            vault_db = getattr(getattr(self.bot, "client", None), "dbase", None)
            vault_db = getattr(vault_db, "vault_pulse_db", None)

            # Housekeeping + active cap
            if vault_db:
                await expire_old_playlists(vault_db)
                await reconcile_deleted_playlists(vault_db, self.bot.client, str(user.id), jf_id)
                active = await count_active_playlists(vault_db, str(user.id))
                if active >= 3:
                    await interaction.response.send_message(
                        "🚫 You already have 3 active playlists. Please delete one or wait for older ones to expire.",
                        ephemeral=True,
                    )
                    return

            # Build item list
            items = await self._generate_playlist_items(num_files, collections, tags)
            if not items:
                await interaction.response.send_message("🤷 No matching audio items found.", ephemeral=True)
                return

            # Friendly sequential name uses Jellyfin username (fallback to Discord name)
            jf_username = await self._get_jellyfin_username(jf_id) or user.name

            # Create Jellyfin playlist with friendly name, get URL + name + jf playlist id
            playlist_url, playlist_name, jf_playlist_id = await self._create_playlist_and_get_url(
                jf_id,
                items,
                vault_db=vault_db,
                discord_id=str(user.id),
                display_name=jf_username,
            )

            # Log to VaultPulse (row + normalized items)
            if vault_db:
                user_playlist_id = await log_playlist_creation(
                    vault_db,
                    discord_id=str(user.id),
                    playlist_name=playlist_name,
                    items=items,
                    collections=collections,
                    tags=tags,
                )
                await log_playlist_items(
                    vault_db,
                    user_playlist_id=user_playlist_id,
                    jf_playlist_id=jf_playlist_id,
                    items=items,
                )

            # DM + confirm
            await self._send_playlist_dm(user, playlist_url)
            await interaction.response.send_message("✅ Playlist sent in DM!", ephemeral=True)

        except discord.Forbidden:
            logger.warning(f"[_send_playlist_dm] Forbidden: Unable to DM user {user} — likely due to privacy settings.")
            fallback = playlist_url or "your Vault+ account"
            await interaction.response.send_message(
                f"❌ Couldn't DM you; check your privacy settings. Your playlist is available at {fallback}.",
                ephemeral=True
            )

        except Exception as e:
            logger.error(f"[_handle_submission] Unexpected error: {e}")
            logger.error(traceback.format_exc())
            await interaction.response.send_message("❌ Something went wrong while creating your playlist.", ephemeral=True)


    def _get_jellyfin_user_id(self, user: discord.User | discord.Member) -> str | None:
        return next(
            (j for j, (discord_id, _) in self.bot.link_map.items() if int(discord_id) == int(user.id)),
            None
        )
        
    async def _get_jellyfin_username(self, jf_user_id) -> str | None:
        tup = self.bot.link_map.get(jf_user_id)
        if tup and len(tup) >= 2 and tup[1]:
            return tup[1]

        return None

    async def _respond_not_linked(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            "❌ No linked Vault+ account found. Please visit <#1376142045621784606> to create an account.\n"
            "If you already have a Vault+ account, please use your **Vault+ username** to link accounts.",
            ephemeral=True
        )

    async def _generate_playlist_items(self, num_files: int, collections: list[str], tags: list[str]):
        logger.info(f"[_generate_playlist_items] Generating playlist with count={num_files}, collections={collections}, tags={tags}")
        return await generate_playlist(
            jellyfin_client=self.bot.client,
            count=num_files,
            collections=collections,
            tags=tags
        )

    async def _create_playlist_and_get_url(
        self,
        jf_id: str,
        items: list,
        *,
        vault_db,
        discord_id: str,
        display_name: str,
    ) -> tuple[str, str, str]:
        """
        Creates Jellyfin playlist using a friendly sequential name.
        Returns (playlist_url, playlist_name, jellyfin_playlist_id).
        """
        # figure out next sequence number
        n = await get_next_playlist_number(vault_db, discord_id)
        playlist_name = build_sequential_name(display_name, n)

        # create on Jellyfin with this name
        jf_playlist_id, playlist_name = await create_playlist(
            jellyfin_client=self.bot.client,
            user_id=jf_id,
            items=items,
            name=playlist_name,
        )
        return build_playlist_url(jf_playlist_id), playlist_name, jf_playlist_id


    async def _send_playlist_dm(self, user: discord.User, playlist_url: str):
        await user.send(f"🎶 Your **Worse+** playlist is ready: {playlist_url}")
