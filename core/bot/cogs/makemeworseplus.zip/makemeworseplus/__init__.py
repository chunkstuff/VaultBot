# core/bot/cogs/makemeworseplus/__init__.py

async def setup(bot):
    from .worseplus import MakeMeWorsePlus
    await bot.add_cog(MakeMeWorsePlus(bot))