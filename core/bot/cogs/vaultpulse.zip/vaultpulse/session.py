import discord
import asyncio
import json
import traceback
from discord.ext import tasks, commands
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path

from config.time_helpers import format_ticks
from config.settings import settings
from utils.logger_factory import setup_logger
from .buffer import BufferManager
from .user import UserSync
from .item_sync import ItemSync
from .embed import EmbedBuilder


logger = setup_logger(__name__)

class VaultPulse(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.client = bot.client
        self.db = self.client.users.sessions.user_session_db
        self.buffer = BufferManager()
        self.user_sync = UserSync(bot)
        self.item_sync = ItemSync(self.client)
        self.embed_builder = EmbedBuilder(self.bot, self.db)

        self.check_sessions.start()
        self.flush_hourly_chunks.start()

    async def cog_unload(self):
        self.check_sessions.cancel()
        self.flush_hourly_chunks.cancel()

    async def flush(self):
        if self.buffer.get_ticks_for_flush():
            try:
                if self.db._conn is None:
                    await self.db.connect()

                await self.db.upsert_users(await self.user_sync.prepare_user_rows(self.buffer, self.embed_builder._cached_users))
                await self.db.upsert_items(await self.item_sync.prepare_item_rows(self.buffer))
                await self.client.users.sessions.flush_buffer(self.buffer.get_ticks_for_flush())

                self.buffer.clear()
            except Exception as e:
                logger.error(f"[SessionMonitor] Failed flush: {e}")

    @tasks.loop(seconds=15)
    async def check_sessions(self):
        try:
            sessions = await self.client.get_sessions()
            if not isinstance(sessions, list):
                return

            active, streaming = self._get_active_and_streaming_sessions(sessions)
            for session in streaming:
                self.buffer.update(session)

            embed = await self.embed_builder.build_status_embed(len(active), len(streaming), streaming)
            await self.embed_builder.update_or_send_embed(embed)

            logger.debug(self.buffer.debug_dump())
            logger.debug(f'Tick tracker: {self.buffer._tick_tracker}')
            logger.debug(f'Buffer: {self.buffer._buffer}')
        except Exception as e:
            logger.error(f"[SessionMonitor] Error: {e}")
            logger.error(traceback.format_exc())

    @check_sessions.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()
        now = datetime.utcnow()
        await asyncio.sleep(15 - now.second % 15)

    @tasks.loop(hours=1)
    async def flush_hourly_chunks(self):
        try:
            await self.flush()
        except Exception as e:
            logger.error(f"[SessionMonitor] Failed to flush buffer: {e}")

    @flush_hourly_chunks.before_loop
    async def before_flush_hourly(self):
        await self.bot.wait_until_ready()
        now = datetime.utcnow()
        seconds_until_next_hour = ((60 - now.minute) * 60) - now.second
        await asyncio.sleep(seconds_until_next_hour)

    def _get_active_and_streaming_sessions(self, sessions):
        now = datetime.utcnow()
        cutoff = now - timedelta(minutes=15)
        active = [s for s in sessions if (ts := s.get("LastActivityDate")) and datetime.fromisoformat(ts.rstrip("Z")) > cutoff]
        streaming = [s for s in active if s.get("NowPlayingItem")]
        return active, streaming


