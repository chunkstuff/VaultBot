# core/bot/cogs/vaultpulse/buffer.py

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta

from utils.logger_factory import setup_logger
from config.time_helpers import format_ticks

logger = setup_logger(__name__)

MAX_JUMP_BACK = 5 * 10_000_000
INIT_BUFFER = 15 * 10_000_000
MAX_TICK_AGE = timedelta(hours=12)


@dataclass
class LastTick:
    ticks: int
    timestamp: float


class BufferManager:
    def __init__(self):
        self._buffer = defaultdict(int)
        self._tick_tracker: dict[tuple[str, str, datetime], int] = {}
        self._last_known_tick: dict[tuple[str, str], LastTick] = {}

    def update(self, session: dict):
        user_id = session.get("UserId")
        item = session.get("NowPlayingItem", {})
        item_id = item.get("Id")
        if not user_id or not item_id:
            return

        ticks = session.get("PlayState", {}).get("PositionTicks", 0)
        now_ts = datetime.utcnow().timestamp()
        hour_key = self._current_hour()

        track_key = (user_id, item_id, hour_key)
        user_item_key = (user_id, item_id)

        if user_item_key not in self._last_known_tick:
            self._handle_initial(user_item_key, track_key, ticks, now_ts, user_id, item_id)
        else:
            self._handle_subsequent(user_item_key, track_key, ticks, now_ts, user_id, item_id)

    def _handle_initial(
        self,
        user_item_key: tuple[str, str],
        track_key: tuple[str, str, datetime],
        ticks: int,
        now_ts: float,
        user_id: str,
        item_id: str,
    ):
        """
        Record first‐seen (user, item). If initial ticks ≤ INIT_BUFFER, seed buffer.
        """
        self._last_known_tick[user_item_key] = LastTick(ticks=ticks, timestamp=now_ts)

        if ticks <= INIT_BUFFER:
            self._tick_tracker[track_key] = ticks
            self._buffer[track_key] += ticks
            logger.debug(
                f"Initial playtime (≤ {format_ticks(INIT_BUFFER)}) "
                f"added for {user_id} on {item_id}: {format_ticks(ticks)}"
            )

        logger.debug(
            f"Initialized tick tracker for {user_id} on {item_id}: {format_ticks(ticks)}"
        )

    def _handle_subsequent(
        self,
        user_item_key: tuple[str, str],
        track_key: tuple[str, str, datetime],
        ticks: int,
        now_ts: float,
        user_id: str,
        item_id: str,
    ):
        """
        After first‐time logic: detect restarts, compute delta, update trackers.
        """
        last = self._last_known_tick[user_item_key]
        last_ticks = self._detect_restart(ticks, last.ticks, user_id, item_id)

        delta = self._safe_delta(ticks, last_ticks)
        if delta <= 0:
            return

        # Save updated last‐known
        self._last_known_tick[user_item_key] = LastTick(ticks=ticks, timestamp=now_ts)
        self._tick_tracker[track_key] = ticks
        self._buffer[track_key] += delta

        logger.debug(f"Delta for {user_id} on {item_id}: {format_ticks(delta)}")
        logger.debug(f"Last known tick for {user_item_key}: {format_ticks(last_ticks)}")

    def _detect_restart(self, current_ticks: int, last_ticks: int, user_id: str, item_id: str) -> int:
        """
        If current_ticks has jumped back more than MAX_JUMP_BACK, treat as a restart.
        Otherwise, return last_ticks unchanged.
        """
        if current_ticks < last_ticks - MAX_JUMP_BACK:
            logger.debug(f"Detected restart: resetting tick tracker for {user_id} on {item_id}")
            return 0
        return last_ticks

    def _prune_old_ticks(self):
        now = datetime.utcnow().timestamp()
        before = len(self._last_known_tick)
        self._last_known_tick = {
            key: last
            for key, last in self._last_known_tick.items()
            if now - last.timestamp < MAX_TICK_AGE.total_seconds()
        }
        after = len(self._last_known_tick)
        logger.debug(f"Pruned _last_known_tick: {before - after} expired entries")

    def _safe_delta(self, current: int, previous: int, max_allowed: int = 60 * 10_000_000) -> int:
        delta = current - previous
        return delta if 0 <= delta <= max_allowed else 0

    def _current_hour(self) -> datetime:
        return datetime.utcnow().replace(minute=0, second=0, microsecond=0)

    def get_user_ids(self) -> set[str]:
        return {user_id for (user_id, _, _) in self._buffer}

    def get_item_ids(self) -> set[str]:
        return {item_id for (_, item_id, _) in self._buffer}

    def get_ticks_for_flush(self) -> dict[tuple[str, str, datetime], int]:
        return dict(self._buffer)

    def clear(self):
        self._buffer.clear()
        self._tick_tracker.clear()
        self.prune_old_ticks()

    def debug_dump(self) -> list[dict]:
        return [
            {"user": uid, "item": iid, "hour": hour.isoformat(), "ticks": ticks}
            for (uid, iid, hour), ticks in self._buffer.items()
        ]
